<!doctype html>
<html lang="en">
    <head></head>
    <body>
        <div class="col col-lg-7 col-md-6 w-100 h-100 bg-white transblock mx-auto" id="idCompte">
            <img class="mx-auto img-logo" src="asset/images/logo-QuizzSA.png" id="idPp">
            <form class="h-75">
                <div class="form-group" >
                    <input type="text" name="" id="" class="form-control col-6 input rounded" placeholder="Nom" aria-describedby="helpId">
                    <small class="text-muted "></small>
                </div> 
                <div class="form-group">
                    <input type="text" name="" id="" class="form-control col-6 input rounded" placeholder="Prenom" aria-describedby="helpId">
                    <small id="helpId" class="text-muted"></small>
                </div>
                <div class="form-group">
                    <input type="text" name="" id="" class="form-control col-6 input rounded" placeholder="Login" aria-describedby="helpId">
                    <small id="helpId" class="text-muted"></small>
                </div> 
                <div class="form-group">
                    <input type="text" name="" id="" class="form-control col-6 input rounded" placeholder="Password" aria-describedby="helpId">
                    <small id="helpId" class="text-muted"></small>
                </div>
                <div class="form-group"> 
                    <input type="text" name="" id="" class="form-control col-6 input rounded" placeholder="Confirmer" aria-describedby="helpId">
                    <small id="helpId" class="text-muted"></small>
                </div>
                <div class="parent-div">Avatar
                        <button class="btn btn-primary btn-seConnecter">Choisir le fichier</button> <span id="errorExt"></span>
                        <input type="file" id="file" name="photoUser">
                </div>
                <button name="sinscire" type="submit" class="btn btn-primary btn-creerCompte col-4 d-block mx-auto">Creer compte</button>
          </form>  
          <img src="asset/images/avatar3.jpg" alt="Avatar" class="rounded-circle pp">
        </div> 
    </body>
</html>
    
