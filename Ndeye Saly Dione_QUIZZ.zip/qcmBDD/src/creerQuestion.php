<!doctype html>
<html lang="en">
  <head></head>
  <body>
    <form class="col-5 mx-auto">
        <div class="form-group row">
            <label for="idTextarea" class="col-2 col-form-label" >Question</label>
            <div class="col-12">
                <textarea class="form-control input" name="" id="idTextarea" rows="3"></textarea>
                <small id="helpId" class="text-muted"></small>
            </div>
        </div>
        <div class="form-group row">
            <label for="idNbre" class="col-4 col-form-label ">Nbre de points </label>
            <div class="col-lg-3 col-10">
                <input  type="number" name="" id="idNbre" class="form-control input" placeholder="" aria-describedby="helpId">
                <small id="helpId" class="text-muted"></small>
            </div>
        </div>  
        <div class="form-group row">
            <label for="idType" class="col-2">Type</label>
            <div class="col-12 col-lg-10">
                <select class="form-control input" name="" id="idType">
                    <option>Donnez le type de question</option>
                    <option>Multiple</option>
                    <option>Simple</option>
                    <option>Texte</option>
                </select>
            </div>
        </div>
  </div>
    </form>
  </body>
</html>