<!doctype html>
<html lang="en">
  <head></head>
  <body>
    <div class="col h-100 d-flex flex-lg-row flex-column">
        <form method="POST">
            <div class="form-group col">
                <label for="idNQst">Nbre question/jeu</label>
                <input type="text" name="" id="idNQst" class="form-control col-4 col-lg-3 ml-2" placeholder="" aria-describedby="helpId">
                <small id="helpId" class="text-muted"></small>
                <button type="submit" class="btn btn-primary mt-1 ml-4 ml-lg-0 btn-ok">Ok</button>
            </div>
        </form>
        <div class="border border-primary h-100 col-12 col-lg-10">
        </div>
    </div>
  </body>
</html>