<?php
?>
<!doctype html>
<html lang="en">
    <head></head>
    <body>
        <div class="col col-md-12 mt-2 w-25 bg-white transblock bloc-interfaceAdmin">
            <img class="mx-auto img-logo" src="asset/images/logo-QuizzSA.png">
            <img src="asset/images/avatar.jpg" alt="Avatar" class="rounded-circle pp-admin">
                <div class="nomUser position-absolute">
                    Lissa Dione
                </div>
            <button name="seConnecter" id="" class="btn btn-primary btn-deconnexion mt-4" type="button" value="">Deconnexion</button>
            <div class="contain-admin mx-0">
                <div class="burger ml-4 mt-2">
                    <span></span>
                </div>
                <div class="menu ml-4">
                    <div class="row">
                            <div class="list-group">
                                <a href="index.php?page=3" class="list-group-item list-group-item-action">Liste des questions<span class="badge"><img src="asset/images/icones/ic-liste.png"></span></a>
                                <a href="index.php?page=4" class="list-group-item list-group-item-action">Creer Admin<span class="badge"><img src="asset/images/icones/ic-ajout.png"></span></a>
                                <a href="index.php?page=5" class="list-group-item list-group-item-action">Liste joueurs<span class="badge"><img src="asset/images/icones/ic-liste.png"></span></a>
                                <a href="index.php?page=6" class="list-group-item list-group-item-action">Creer questions<span class="badge"><img src="asset/images/icones/ic-ajout.png"></span></a>
                            </div>
                     </div>
                </div>
                <div class="redirection pt-0 mt-2 mx-auto overflow-auto">
                    <?php
                        if($_GET["page"]==3){
                            require "src/listeQuestions.php";
                        }
                        if($_GET["page"]==4){
                            require "src/creationCompte.php";
                            ?>
                                <script>
                                   var blocCreerCompte = document.querySelector("#idCompte");
                                   blocCreerCompte.classList.remove("bg-white");
                                   blocCreerCompte.classList.add("top-style");
                                   var idPp = document.querySelector("#idPp");
                                   idPp.src="";
                                </script>
                            <?php
                        }
                        if($_GET["page"]==5){
                            require "src/listeJoueurs.php";
                        }
                        if($_GET["page"]==6){
                            require "src/creerQuestion.php";
                        }
                    ?>
                </div>
            </div>
        </div>    
    </body>
</html>