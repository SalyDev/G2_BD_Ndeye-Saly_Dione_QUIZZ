<?php
    
?>
<!doctype html>
<html lang="en">
    <head></head>
    <body>
        <div class="col col-md-12 mt-2 w-25 bg-white transblock bloc-interfaceAdmin">
            <img class="mx-auto img-logo" src="asset/images/logo-QuizzSA.png">
            <img src="asset/images/avatar3.jpg" alt="Avatar" class="rounded-circle pp-admin">
                <div class="nomUser position-absolute">
                    Rita Diouf
                </div>
            <button name="deconnexion" id="" class="btn btn-primary btn-deconnexion mt-4" type="button" value="">Deconnexion</button>
            <div class="contain-admin mx-0 d-flex flex-column flex-lg-row flex-md-row">
                <div class="zone-gauche col col-lg-7 h-100 h-lg-100 col-md-7 h-md-100 shadow ml-lg-2 ml-md-2 overflow-auto">
                   <div class="zone-haut col-11 mt-2 border border-primary mx-auto">
                       <p class="col-2 border border-secondary float-left h-100"></p>
                       <p class="col-2 border border-secondary float-right h-100"></p>
                    </div>
                    <div class="zone-milieu col-11 mt-2 border border-primary mx-auto h-75">
                        <div class="zone-AfficheQst border border-primary h-25"></div>
                        <div class="border border-primary h-75"></div>
                    </div>
                    <div class="zone-bas col-11 mt-2 border border-primary mx-auto">
                    <button name="precedent" id="" class="btn btn-primary btn-deconnexion float-left" type="button" value="">Precedent</button>
                    <button name="suivant" id="" class="btn btn-primary btn-seConnecter  float-right" type="button" value="">Suivant</button>
                    </div>
                </div>
                <div class="zone-droite col h-75 col-lg-3 ml-lg-5 mt-lg-3 col-md-4 ml-md-5 mt-md-3 mt-2 mt-lg-0 mt-md-0 shadow overflow-auto">
                    <div class="border border-primary h-25">
                        <div class="list-group d-flex flex-row" id="list-tab" role="tablist">
                            <a class="list-group-item list-group-item-action active" id="list-home-list" data-toggle="list" href="#list-home" role="tab" aria-controls="home">Top Scores</a>
                            <a class="list-group-item list-group-item-action" id="list-profile-list" data-toggle="list" href="#list-profile" role="tab" aria-controls="profile">Mon meilleur score</a>
                        </div>
                    </div>
                    <div class="border border-primary h-75">
                        <div class="tab-content" id="nav-tabContent">
                            <div class="tab-pane fade show active" id="list-home" role="tabpanel" aria-labelledby="list-home-list">...</div>
                            <div class="tab-pane fade" id="list-profile" role="tabpanel" aria-labelledby="list-profile-list">...</div>
                        </div>
                    </div>
                </div>
            </div>       
        </div>
    </body>
</html>