//fonction permettant d'afficher un message d'erreur sur un emplcement specifique
function affichError(emplacement,msg){
    emplacement.innerText=msg;
 }
   
 //on verifie que l'admin a donne plus de 2 reponses possibles pour les qst a choix multiple et simple et une reponse possible pour le texte
var nbreRepMultiple=document.formulaire.nbreRepMultiple.value;
var nbreRepSimple=document.formulaire.nbreRepSimple.value;
const inputs = document.getElementsByTagName("input");
var formulaire = document.querySelector('#createQst-form');
formulaire.addEventListener('submit',function(){
    if(document.formulaire.type.selectedIndex=="0"){
        affichError(document.getElementById("error3"),"Donner le type de reponse");

    }
    //si la question est de type choix multiple
    if(document.formulaire.type.selectedIndex=="1"){
    //si le nbre de reponse possible est inferieur a 2
        if(nbreRepMultiple<2){
            // document.getElementById('ereur').innerText="hhchcgh";
            affichError(document.getElementById("ereur"),"Donner au moins deux reponses possibles");
        }
        else{
            document.getElementById('ereur').innerText="";
        }
        // on verifie que la bonne reponse est indiquee
        // on initialise un compteur a 0
        // si une bonne reponse est indiquee on incremente le compeuteur
        compteur=0;
        for(i=0;i<nbreRepMultiple;i++){
            if(document.getElementById("choice"+i).checked){
                compteur++;
            }
            //si le compteur est egal a 0 ca veut dire qu'aucune bonne reponse n'a ete indique et on affiche le msg d'erreur
            if(compteur==0){
                affichError(document.getElementById("ereur"),"Veuillez indiquer la ou les bonnes reponses");
            }
            else{
                affichError(document.getElementById("ereur"),"")
            }

        }
    }
    //on fait la mm chose pour les question a choix simple
    if(document.formulaire.type.value=="simple"){
        if(nbreRepSimple<2){
            affichError(document.getElementById("ereur"),"Donner au moins deux reponses possibles");
        }
        else{
          affichError(document.getElementById("ereur"),"");  
        }
        count=0;
        for(i=0;i<nbreRepSimple;i++){
            if(document.formulaire.choice[i].checked){
                count++;
            }
        }
        if(count==0){
            affichError(document.getElementById("ereur"),"Veuillez indiquer la ou les bonnes reponses");
        }
    }
    //choix texte
    if(document.formulaire.type.value=="texte"){
        if(document.querySelector('.nbre').innerHTML==""){
            affichError(document.getElementById("ereur"),"Veuillez indiquer la bonne reponse");
        }
        else{
            affichError(document.getElementById("ereur"),"");
        }
    }

    //on verifie que les champs input ne sont pas vides
    for(input of inputs){
        if(input.hasAttribute("error")){
            var idDivError=input.getAttribute("error");
            if(!input.value){
                document.getElementById(idDivError).innerText="Obligatoire";
                document.getElementById(idDivError).style.color="red";
            }
            else{
                document.getElementById(idDivError).innerText="";
            }
        }
    }
    //on verifie que tous les champs ont ete remplis
   var n=0;
   var m=0;
   for(input of inputs){
    if(!input.value){
        n++
    }
   }
});
//gestion de la generation des inputs
var nbre;
var i;
var valeur;
var nbreRep;
//la variable nbreRepMultiple represente le nombre de reponses multiples possibles
//la variable nbreRepSimple represente le nombre de reponses simples possibles
 // var nbreRepMultiple=document.formulaire.nbreRepMultiple.value;
var nbreRepMultiple=0;
var nbreRepSimple=0;
document.formulaire.nbreRepMultiple.value=nbreRepMultiple;
document.formulaire.nbreRepSimple.value=nbreRepSimple;

//cette fonction permet de supprimer une reponse possible et prends comme parametre l'id de la reponse
function suppression(monid){
    //on supprime la reponse consernee
    document.querySelector('.reponse'+monid).innerHTML="";
    //decremente le nombre de reponses possibles et on l'affecte de nouveau dans l'input stockant le nbre de reponse possibles
    if(document.formulaire.type.selectedIndex=="1"){
        nbreRepMultiple--;
        document.formulaire.nbreRepMultiple.value=nbreRepMultiple;
    }
    if(document.formulaire.type.selectedIndex=="2"){
        nbreRepSimple--;
        document.formulaire.nbreRepSimple.value=nbreRepSimple;
    }
}
//la fonction ajout permet d'ajouter une reponse possible
var ajout = document.getElementById('ajout-qst');
ajout.addEventListener('click',function(){
    // alert('ajout');
    j=0;
    if(document.formulaire.type.selectedIndex=="1"){
        while(j<4){
            if(document.querySelector('.reponse'+j).innerHTML==""){
                document.querySelector('.reponse'+j).innerHTML = "<div class=\"form-group row\"><label class=\"col-3\">Reponse "+(j+1)+"</label><input type=\"text\" class=\"form-control col-lg-7 col-md-7 input\" name=\"rep"+j+"\" error=\"erreur"+j+"\" id=\"rep"+j+"\"><input type=\"checkbox\" class=\"ml-1 mt-3\" name=\"choiceMulti"+j+"\" id=\"choice"+j+"\" value=\"reponse"+(j+1)+"\"><a href=\"#\" onclick=\"suppression("+j+"\)\"><span class=\"corbeille ml-1 mt-2\"></span></a><small id=\"erreur"+j+"\" class=\"text-danger\"></small>";
                nbreRepMultiple++;
                document.formulaire.nbreRepMultiple.value=nbreRepMultiple;
                break;
            }
            j++; 
        }
    }
    if(document.formulaire.type.selectedIndex=="2"){
        k=0;
        while(k<4){
            if(document.querySelector('.reponse'+k).innerHTML==""){
                nbreRepSimple++;
                document.formulaire.nbreRepSimple.value=nbreRepSimple;
                document.querySelector('.reponse'+k).innerHTML = "<div class=\"form-group row\"><label class=\"col-3\">Reponse "+(k+1)+"</label><input type=\"text\" class=\"form-control input col-md-7 col-lg-7\" name=\"rep"+k+"\" error=\"erreur"+k+"\" id=\"rep"+k+"\"><input type=\"radio\" class=\"ml-1 mt-3\" name=\"choice\" value=\"reponse"+(k+1)+"\"><a href=\"#\" onclick=\"suppression("+k+"\)\"><span class=\"corbeille ml-1 mt-2\"></span></a><small class=\"text-danger\" id=\"erreur"+k+"\"></small></div>";
            break;
            }   
            k++;
        } 
    }  
    if(document.formulaire.type.selectedIndex=="3"){
        document.querySelector('.nbre').innerHTML = "<div class=\"form-group row\"><label class=\"col-3\">Reponse</label><input type=\"text\" class=\"form-control col-lg-7 col-md-7 input\" name=\"rep\" classe=\"syleRep\" error=\"error6\"><small id=\"error6\" class=\"text-danger\"></small></div>";
    }
});

//fonction permettant de renouveller le choix du type de question
var type = document.querySelector('#type');
type.addEventListener('change',function(){
    document.querySelector('.nbre').innerHTML = "";
    for(i=0;i<4;i++){
        document.querySelector('.reponse'+i).innerHTML = "";  
    }
});
//fonction permettant de fixer le nombre de questions par jeu
function nbreQuestion(){
    nombreQst=document.formulaire.nombreQst.value;
    if(nombreQst==""){
           //on affiche le message d'erreur
        affichError(document.getElementById("ereur"),"*Champs vide");
        return false;
    }
    nbreValid = /[0-9]/;
    if(!(nbreValid.test(nombreQst) && nombreQst>=5)){
        //on affiche le message d'erreur
        affichError(document.getElementById("ereur"),"Veuillez donner un entier superieur ou egal à 5");
        return false;
    }
}
