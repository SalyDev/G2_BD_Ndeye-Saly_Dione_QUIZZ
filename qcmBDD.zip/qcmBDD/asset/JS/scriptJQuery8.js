$(document).ready(function(){
    $('#submit').on('click',function(e){
        e.preventDefault();
            var login = $('#log').val(),
            password = $('#pass').val();
        if(login=="" || password==""){
            // si le login ou le mot de passe est vide
            alert("Donner votre login et votre mot de passe");
        }
        else{
            // sinon
            // on envoie les donnees vers le serveur
            $.post(
            'index.php',
            {
                loginSent:login,
                passwordSent:password
            },
            function(response){
                $('#erreur').html(response);
                if(response.indexOf("Vous êtes connecté en tant que joueur")>=0){
                    window.location = 'src/interfaceJoueur.php';
                    // $('body').load('http://localhost/qcmBDD/src/interfaceJoueur.php');
                }
                if(response.indexOf("Vous êtes connecté en tant qu'administrateur")>=0){
                    window.location = 'src/interfaceAdmin.php';
                }
            },
            'html'
            );
        }
    });
// redirection vers la page d'inscription
$('#createCompte').click(function(){
    // window.location = 'index.php?page=0';
    $('#centre').load('http://localhost/qcmBDD/src/inscriptionJoueur.php');
});

//les onglets de menu de la page admin
$('#list_1').on('click',function(){
    // $('#redirection').load('http://localhost/qcmBDD/src/listeQuestions.php');
});
$('#list_2').on('click',function(){
    $('#redirection').load('http://localhost/qcmBDD/src/inscriptionAdmin.php');
  
});
$('#list_3').on('click',function(){
    $('#redirection').load('http://localhost/qcmBDD/src/listeJoueurs.php');
});
$('#list_4').on('click',function(){
    $('#redirection').load('http://localhost/qcmBDD/src/creerQuestion.php');
});


//------inscription---------
    //on recupere les donnees saisies par le user
    var $nom = $('#nom');
    var $prenom = $('#prenom');
    var $login = $('#login');
    var $password = $('#password');
    var $confirm = $('#confirm');
    var $uploadPP = $('#uploadPP');
    var $nomValid,$prenomValid,$loginValid,$pwdValid,$confirmValid,$validFile;

    //on verifie le nom
    var validName= new RegExp('^[A-Z][a-zéèê]+(([ ][A-Z][a-zéèê]+)+)?$');
    $nom.keyup(function(){
        if(!validName.test($(this).val())){
           $(this).css({
               borderColor:'red',
               color:'red'
           }); 
           $('#errorNom').text("Nom incorrecte");
           $nomValid=true;
        }
        else{
            $(this).css({
                borderColor:'green',
                color:'green'
            });
            $('#errorNom').text("");
            $nomValid=true;
        }
    });
      //on verifie le prenom
      $prenom.keyup(function(e){
          // $name=$(this).val();
          if(!validName.test($(this).val())){
             $(this).css({
                 borderColor:'red',
                 color:'red'
             }); 
             $('#errorPrenom').text("Prenom incorrecte");
             e.preventDefault();
             $prenomValid=false;
          }
          else{
              $(this).css({
                  borderColor:'green',
                  color:'green'
              });
              $('#errorPrenom').text("");
              $prenomValid=true;
          }
      })

      //on verifie que le user a donne un login
      $login.keyup(function(){
          if($login.val()!=""){
            $(this).css({
                borderColor:'green',
                color:'green'
            });
            $loginValid = true;
          }
          else{
              $loginValid=false;
          }
      });

    //on verifie le password
    $password.keyup(function(){
        if($password.val().length<5){
                $(this).css({
                    borderColor:'red',
                    color:'red'
                }); 
                $pwdValid = false;
                $('#errorPwd').text("Le password doit contenir au moins 5 caracteres");
        }
        else{
            $(this).css({
                borderColor:'green',
                color:'green'
            });  
            $('#errorPwd').text("");
            $pwdValid = true;
        }
    });

    // on verifie si les pwd sont identiques
    $('#confirm').keyup(function(){
        if($confirm.val()!=$password.val()){
            $(this).css({
                borderColor:'red',
                color:'red'
            });
            $confirmValid=false;
            $('#errorConfirm').text("Mots de passe non identiques");  
        }
        else{
            $(this).css({
                borderColor:'green',
                color:'green'
            });
            $('#errorConfirm').text("");
            $confirmValid = true;
        }
    });
    //on verifie qu'aucun champs n'est vide
    function verifyEmpty(input){
        if(input.val() == ""){
            //       si le champs est vide
            $('#erreur').addClass('d-block');
            $('#erreur').text("Veuillez remplir tous les champs");
            // on affiche le msg d'erreur
            input.css({
                borderColor:'red',
                color:'red'
            });
        }
      }

        //fonction permettant de previsualiser l'image
        function PreviewImg(input){
            if(input.files){
                //on fait la lecture du fichier
                var reader = new FileReader();
                //on declenche un evenement au chargement termine du fichier
                reader.onload = function(e){
                    $('#pp').attr('src',e.target.result);
                    $('#pp').addClass('pp');
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
    
      //on verifie le fichier choisie par le user
      $('#uploadPP').change(function(){
        //on recupere le fichier charge
        let $fichier = $(this).val();
        //on verifie l'extension du fichier
        let $extension = $fichier.substring($fichier.lastIndexOf('.')+1).toLowerCase();
        // les extensions permis
        let $allowedExtensions = ['jpg','jpeg','png'];
        if($.inArray($extension,$allowedExtensions)!=-1){
            // si le fichier a le bon extension
            // on lit le contenu du fichier
            PreviewImg(this);
            $validFile = true;
        }
        else{
            // sinon
            $('#errorFile').text('Type de fichier non permis');
            $validFile = false;
        }

      });

    //   l'envoie des donnees du formulaire
        $('#idForm').on('submit', function(e){
            e.preventDefault();
            verifyEmpty($nom);
            verifyEmpty($prenom);
            verifyEmpty($login);
            verifyEmpty($password);
            verifyEmpty($confirm);
            var form = $(this);
            var formdata = new FormData(form[0]);
            if($nomValid==true && $prenomValid==true && $loginValid==true && $pwdValid==true && $confirmValid==true && $validFile==true){
                $.ajax({
                    url:'http://localhost/qcmBDD/src/data.php',
                    type:'POST',
                    contentType:false,
                    processData:false,
                    data:formdata,
                    dataType : 'html',
                    success: function(response){
                        $('#error_compte').html(response);
                        if(response.indexOf("Votre compte a été crée avec succes")>=0){
                            window.location = 'index.php';
                            // $('body').load('http://localhost/qcmBDD/src/interfaceJoueur.php');
                        }
                    }
                })
            }
        })
// creation de question
    var $question = $('#question'),
        $nbrePts = $('#nbrePts'),
        selectedType,
        i = 0;
     // quand on soumet le formulaire
    $('#createQst-form').on('submit',function(e){
        e.preventDefault();
        //on verifie que la qst est donnee
        if($question.val()==""){
             $('#error1').text('Champs Obligatoire');
        }
        else{
             $('#error1').text('');
        }
        if($nbrePts.val()==""){
             $('#error2').text('Champs Obligatoire');
        }
        else if($nbrePts.val()<1){
             $('#error2').text('Incorrect');
        }
        else{
            $('#error2').text('');
        }

        //enregistrement de question
        $.post(
            'http://localhost/qcmBDD/traitement/traitementQst.php',
            {
                formulaire:$(this).serialize()
            },
            function(response){
                console.log(response);
            },
            'text'
        );
    });


});



