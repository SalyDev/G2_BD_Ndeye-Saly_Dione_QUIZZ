//fonction de validation des donnees d'inscription
$(document).ready(function(){
    //on recupere les donnees saisies par le user
    var $nom = $('#nom');
    var $prenom = $('#prenom');
    var $login = $('#login');
    var $password = $('#password');
    var $confirm = $('#confirm');
    var $uploadPP = $('#uploadPP');
    var $nomValid,$prenomValid,$loginValid,$pwdValid,$confirmValid,$validFile;

    //on verifie le nom
    var validName= new RegExp('^[A-Z][a-zéèê]+(([ ][A-Z][a-zéèê]+)+)?$');
    $nom.keyup(function(){
        if(!validName.test($(this).val())){
           $(this).css({
               borderColor:'red',
               color:'red'
           }); 
           $('#errorNom').text("Nom incorrecte");
           $nomValid=true;
        }
        else{
            $(this).css({
                borderColor:'green',
                color:'green'
            });
            $('#errorNom').text("");
            $nomValid=true;
        }
    });
      //on verifie le prenom
      $prenom.keyup(function(e){
          // $name=$(this).val();
          if(!validName.test($(this).val())){
             $(this).css({
                 borderColor:'red',
                 color:'red'
             }); 
             $('#errorPrenom').text("Prenom incorrecte");
             e.preventDefault();
             $prenomValid=false;
          }
          else{
              $(this).css({
                  borderColor:'green',
                  color:'green'
              });
              $('#errorPrenom').text("");
              $prenomValid=true;
          }
      })

      //on verifie que le user a donne un login
      $login.keyup(function(){
          if($login.val()!=""){
            $(this).css({
                borderColor:'green',
                color:'green'
            });
            $loginValid = true;
          }
          else{
              $loginValid=false;
          }
      });

    //on verifie le password
    $password.keyup(function(){
        if($password.val().length<5){
                $(this).css({
                    borderColor:'red',
                    color:'red'
                }); 
                $pwdValid = false;
                $('#errorPwd').text("Le password doit contenir au moins 5 caracteres");
        }
        else{
            $(this).css({
                borderColor:'green',
                color:'green'
            });  
            $('#errorPwd').text("");
            $pwdValid = true;
        }
    });

    // on verifie si les pwd sont identiques
    $('#confirm').keyup(function(){
        if($confirm.val()!=$password.val()){
            $(this).css({
                borderColor:'red',
                color:'red'
            });
            $confirmValid=false;
            $('#errorConfirm').text("Mots de passe non identiques");  
        }
        else{
            $(this).css({
                borderColor:'green',
                color:'green'
            });
            $('#errorConfirm').text("");
            $confirmValid = true;
        }
    });
    //on verifie qu'aucun champs n'est vide
    function verifyEmpty(input){
        if(input.val() == ""){
            //       si le champs est vide
            $('#erreur').addClass('d-block');
            $('#erreur').text("Veuillez remplir tous les champs");
            // on affiche le msg d'erreur
            input.css({
                borderColor:'red',
                color:'red'
            });
        }
      }

        //fonction permettant de previsualiser l'image
        function PreviewImg(input){
            if(input.files){
                //on fait la lecture du fichier
                var reader = new FileReader();
                //on declenche un evenement au chargement termine du fichier
                reader.onload = function(e){
                    $('#pp').attr('src',e.target.result);
                    $('#pp').addClass('pp');
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
    
      //on verifie le fichier choisie par le user
      $('#uploadPP').change(function(){
        //on recupere le fichier charge
        let $fichier = $(this).val();
        //on verifie l'extension du fichier
        let $extension = $fichier.substring($fichier.lastIndexOf('.')+1).toLowerCase();
        // les extensions permis
        $allowedExtensions = ['jpg','jpeg','png'];
        if($.inArray($extension,$allowedExtensions)!=-1){
            // si le fichier a le bon extension
            // on lit le contenu du fichier
            PreviewImg(this);
            $validFile = true;
        }
        else{
            // sinon
            $('#errorFile').text('Type de fichier non permis');
            $validFile = false;
        }

      });

    
    //lorsque le l'user soumet le formulaire
    $('#btn-inscrire').on('click',function(){
        // alert($login.val());
        verifyEmpty($nom);
        verifyEmpty($prenom);
        verifyEmpty($login);
        verifyEmpty($password);
        verifyEmpty($confirm);
        if($nomValid==true && $prenomValid==true && $loginValid==true && $pwdValid==true && $confirmValid==true && $validFile==true){
            //on envoie les donnees au serveur
            // alert("Bravo");
            $.post(
                'test.php',
                {
                   loginEnvoye:$login.val(),
                   passwordEnvoye:$password.val()
                },
                function(response){
                  //la reponse du serveur
                  console.log(response);
                },
                'html'
                );

        }
        else{
            // e.preventDefault();
            // alert("Fail");
        }
    });
});
