<?php
require "../src/fonctions.php";
print_r($_POST["formulaire"]);
parse_str($_POST["formulaire"], $form);
// echo $form["nbrePoints"];
//validation cote serveur
$compteur=0;
$retour1=$retour2=$retour3="faux";
$nbreRepMultiple=$form["nbreRepMultiple"];
$nbreRepSimple=$form["nbreRepSimple"];
if($form["question"]!="" && $form["nbrePoints"]>=1){
	$retour1 = "vrai";
}

// on verifie que les questions a choix simple et multiple on au moins 2 reponses possibles donnees et qu'elles ne sont pas vides
$isFull=0;
if(($form["type"]=="multiple" && $form["nbreRepMultiple"]>=2) || ($form["type"]=="simple" && $form["nbreRepSimple"]>=2)){
	if($form["type"]=="multiple"){
	$nbreRep = $nbreRepMultiple;
	}
	if($form["type"]=="simple"){
		$nbreRep = $nbreRepSimple;
	}
	for($i=0;$i<$nbreRep;$i++){
		if(isset($form['rep'.$i]) && $form['rep'.$i]!=""){
			$isFull++;
		}
}
	if($isFull==$nbreRep){
		$retour2="vrai";
	}
}
//on verifie qu'on a le user a rensigne la reponse exacte a la question 
$retour3="faux";
if($form["type"]=="multiple"){
	for($i=0;$i<$nbreRepMultiple;$i++){
		if(isset($form['choiceMulti'.$i])){
			$compteur++;
		}
	}
}
if($compteur!=0){
	$retour3 = "vrai";
}
if($form["type"]=="simple"){
	if(isset($form["choice"])){
		$retour3="vrai";
	}
}
//question texte
if($form["type"]=="texte" && isset($form["rep"])){
	if($form["rep"]!=""){
		$retour3 = "vrai";
		$retour2 = "vrai";
	}
}
if($retour1=="faux" || $retour2=="faux" || $retour3=="faux"){
	//on n'enregistre pas les donnees dans la bd
	echo "echo veuillez remplir le formulaire correctement";

}
else{
	//si tt est ok, on enregistre les donnees dans la bd
	$bdd = connexionBD();
	$data = $bdd->prepare('INSERT INTO question(type, nbrePoints, libelle)
                            VALUES(:type, :nbrePoints, :libelle)'
                        );
    $data->execute(array(
        'type' => $form["type"],
        'nbrePoints' => $form["nbrePoints"],
        'libelle' => $form["question"]
    ));
    //insertion des reponses
    $libelleRep=[];
    $exact=[];
    if($form["type"]=="multiple" || $form["type"]=="simple"){
    	if($form["type"]=="multiple"){
    		for($i=0;$i<$nbreRepMultiple;$i++){
    			if(isset($form['choiceMulti'.$i])){
    				$exact[$i]=1;
    			}
    			else{
    				$exact[$i]=0;
    			}
    		}
    	}
    	if($form["type"]=="simple"){
    		for($i=0;$i<$nbreRepSimple;$i++){
    			if($form["choice"]=='reponse'.($i+1)){
    				$exact[$i]=1;
    			}
    			else{
    				$exact[$i]=0;
    			}
    		}
    	}
    	for($i=0;$i<$nbreRep;$i++){
    		$libelleRep[]=$form['rep'.$i];
    		$data = $bdd->prepare('INSERT INTO reponse(libelle,exact)
                            VALUES(:libelle, :exact)'
                        );
	    	$data->execute(array(
		        'libelle' => $libelleRep[$i],
		        'exact' => $exact[$i]
	        ));
    	}
    }
    if($form["type"]=="texte"){
    	$data = $bdd->prepare('INSERT INTO reponse(libelle,exact)
                            VALUES(:libelle, :exact)'
                        	);
	    $data->execute(array(
		    'libelle' => $form["rep"],
		    'exact' => 1
	    ));
	    $nbreRep=1;
    }
    $reponses=[];
    $data1 = $bdd->query("SELECT numQST FROM question ORDER BY numQST DESC LIMIT 1");
    $data2 = $bdd->query("SELECT idReponse FROM reponse ORDER BY idReponse DESC LIMIT $nbreRep");
    while($donnees=$data2->fetch()){
    	$reponses[]=$donnees["idReponse"];
    } 
     while($donnees=$data1->fetch()){
    	$question=$donnees["numQST"];
    }
    //on enregistre les donnees dans avoir
    for($i=0;$i<$nbreRep;$i++){
    	$data = $bdd->prepare('INSERT INTO avoir(idReponse,numQST)
                            VALUES(:idReponse, :numQST)'
                        );
	    $data->execute(array(
	    	'idReponse' => $reponses[$i],
	     	'numQST' => $question
	     ));
	    }

	}

?>