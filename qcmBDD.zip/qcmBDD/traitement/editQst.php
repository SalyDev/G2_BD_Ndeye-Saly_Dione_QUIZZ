<?php
	require "../src/fonctions.php";
	$bdd= connexionBD();
	if(isset($_POST["idQst"])){
		// echo "bravo";
		echo $_POST["idQst"];
		//on supprime le champs dans la table avoir pour des soucis de contraintes d'integrite
		$data = $bdd->prepare('DELETE FROM avoir WHERE avoir.numQST=:numQST');
		$data->execute(array('numQST'=>$_POST['idQst']));
		//maintenant  on supprime le champs dans la table question 
		$data = $bdd->prepare('DELETE FROM question WHERE question.numQST=:numQST');
		$data->execute(array('numQST'=>$_POST['idQst']));

	}

	//modification de questions
	if(isset($_POST["idEdit"])){
		echo "gagne";
		echo $_POST["idEdit"];
		//on modifie la question
	}
	else{
		echo "perdu";
	}
?>