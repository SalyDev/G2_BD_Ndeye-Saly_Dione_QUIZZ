<?php
	require "../src/fonctions.php";
	if(isset($_POST["offset"])){
		$offset=$_POST["offset"];
		$limit=$_POST["limit"];
		$bdd = connexionBD();
		//on recupere les questions
		$sql = "
		SELECT question.libelle as libelle, question.type as type,question.numQST as numQST
		FROM question
		LIMIT $limit
		OFFSET $offset
		";	
		$data=$bdd->query($sql);
		$donnnes=$data->fetchAll(2);
		//on recupere les reponses
		$sql = "
		SELECT reponse.libelle as reponse, reponse.exact as exact, avoir.numQST as numQST
		FROM reponse INNER JOIN avoir
		ON reponse.idReponse = avoir.idReponse
		";
		$data2=$bdd->query($sql);
		$donnnes2=$data2->fetchAll(2);
		//on associe pour chaque question ses reponses
		$qcm=[];
		// $qcm['reponse']=[];
		for($i=0;$i<count($donnnes);$i++){
			$qcm['question'][$i]=$donnnes[$i]['libelle'];
			$qcm['type'][$i]=$donnnes[$i]['type'];
			$qcm['numQST'][$i]=$donnnes[$i]['numQST'];
		}

		for($i=0;$i<count($donnnes);$i++){
			for($j=0;$j<count($donnnes2);$j++){
				if($donnnes[$i]['numQST']==$donnnes2[$j]['numQST']){
					$qcm['reponse'][$i][]=$donnnes2[$j]['reponse'];
					$qcm['exact'][$i][]=$donnnes2[$j]['exact'];
				}
			}
		}
		$qcm = json_encode($qcm);
		echo $qcm;
	}
	else{
	echo "failed";
	}
?>