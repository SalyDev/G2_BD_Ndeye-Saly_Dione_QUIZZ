<?php
// fonction permettant la connexion a ma base de donnees
function connexionBD(){
try
    {
       return $bdd = new PDO('mysql:host=localhost;port=3308;dbname=quizz','root', '',array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION));
    }catch(Exception $e)
    {
         die('Erreur de connexion');
        return null;
    }
}
//fonction qui permet de se deconnecter
function deconnexion(){
    if(isset($_POST["deconnexion"]) || !isset($_SESSION["login"])){
        header("Location:../index.php");
        session_destroy();
    }
}

?>