        <p class="text-center erreur text-white bg-danger w-100 d-none" id="erreur"></p>
           <div class="w-75 text-success mb-3" id="error_compte"></div>
            <form class="h-75" method="POST" id="idForm" enctype="multipart/form-data">
                <div class="form-group">
                    <input type="text" name="nom" id="nom" class="form-control col-6 input rounded" placeholder="Nom" aria-describedby="helpId">
                    <small id="errorNom" class="text-danger"></small>
                </div> 
                <div class="form-group">
                    <input type="text" name="prenom" id="prenom" class="form-control col-6 input rounded" placeholder="Prenom" aria-describedby="helpId">
                    <small id="errorPrenom" class="text-danger"></small>
                </div>
                <div class="form-group">
                    <input type="text" name="login" id="login" class="form-control col-6 input rounded" placeholder="Login" aria-describedby="helpId">
                    <small id="errorLogin" class="text-danger"></small>
                </div> 
                <div class="form-group">
                    <input type="password" name="password" id="password" class="form-control col-6 input rounded" placeholder="Password" aria-describedby="helpId">
                    <small id="errorPwd" class="text-danger"></small>
                </div>
                <div class="form-group"> 
                    <input type="password" name="confirm" id="confirm" class="form-control col-6 input rounded" placeholder="Confirmer" aria-describedby="helpId">
                    <small id="errorConfirm" class="text-danger"></small>
                </div>
                <div class="parent-div" id="env">Avatar
                        <button class="btn btn-primary btn-seConnecter">Choisir le fichier</button> <span id="errorExt"></span>
                        <input type="file" id="uploadPP" name="photoUser">
                        <small id="errorFile" class="text-danger"></small>
                </div>
                <button name="sinscire" id="btn-inscrire" type="submit" class="btn btn-primary btn-creerCompte col-4 d-block mx-auto">Creer compte</button>
                <img id="pp" class="rounded-circle">
          </form>  
  



    
