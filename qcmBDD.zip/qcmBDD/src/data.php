<?php
session_start();
require "fonctions.php";
if(isset($_SESSION["login"])){
    $profil = "admin";
    
}
else{
    $profil = "joueur";
    
}
$bdd = connexionBD();
$chemin = '../asset/images/';
$new_file = $chemin.basename($_FILES['photoUser']['name']);
//on copie les images dans notre dossier specifique $chemin
move_uploaded_file($_FILES["photoUser"]["tmp_name"], $new_file);
$data = $bdd->prepare('SELECT idUser FROM users WHERE users.login LIKE :login');
$data->execute(array('login' => $_POST['login']));
// on verifie si le login n'existe pas deja
if($data->rowCount() > 0){
    // si le login existe
    exit('<p class="text-danger">Login existant</p>');
}
else{
    //sinon on insere les donnees dans la base
    //on crypte le mot de passe
    $password = password_hash($_POST["password"], PASSWORD_DEFAULT);
    $data = $bdd->prepare('INSERT INTO users(login, password, prenom, nom, profil, avatar)
                            VALUES(:login, :password, :prenom, :nom, :profil, :avatar)'
                        );
    $data->execute(array(
        'login' => $_POST["login"],
        'password' => $password,
        'prenom' => $_POST["prenom"],
        'nom' => $_POST["nom"],
        'profil' => $profil,
        'avatar' => $new_file
    ));
    if(isset($_SESSION["login"])){
        echo "compte créé";
    }
    else{
        echo "Votre compte a été crée avec succes";
    }
}

?>