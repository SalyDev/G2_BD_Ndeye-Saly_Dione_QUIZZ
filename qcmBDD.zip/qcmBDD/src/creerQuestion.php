<!doctype html>
<html lang="en">
    <head></head>
    <body>
<!--     <div class="col 7container border border-primary"> -->

        <form name="formulaire" class="col-lg-5 col-md-5 col-12 mx-auto border border-secondary h-100 overflow-auto" id="createQst-form">
            <div class="text-danger" id="ereur"></div>
            <div class="form-group row">
                <label for="idTextarea" class="col-2 col-form-label">Question</label>
                <div class="col-12">
                    <textarea class="form-control input" name="question" id="question" rows="3"></textarea>
                    <small id="error1" class="text-danger"></small>
                </div>
            </div>
            <div class="form-group row">
                <label for="idNbre" class="col-4 col-form-label ">Nbre de points </label>
                <div class="col-lg-3 col-md-3 col-10">
                    <input  type="number" name="nbrePoints" id="nbrePts" class="form-control input" placeholder="" aria-describedby="helpId">
                    <small id="error2" class="text-danger"></small>
                </div>
            </div>  
            <div class="form-group row">
                <label for="idNbre" class="col-2 col-form-label">Type</label>
                <select name="type" class="form-control input col-lg-8 col-md-8" aria-describedby="helpId" id="type">
                    <option value="">Donnez le type de question</option>
                    <option value="multiple">Multiple</option>
                    <option value="simple">Simple</option>
                    <option value="texte">Texte</option>
                </select>
                <div class="input-group-append">
                  <span class="input-group-text ajout-qst" id="ajout-qst"></span>
                </div>
                 <small id="error3" class="text-danger ml-5"></small>
            </div>
             <div class="nbre"></div>
            <div class="nbre d-none"></div>
              <?php 
                for($i=0;$i<4;$i++){?>
                    <div class="<?php echo 'reponse'.$i?>"></div>
                <?php
                }
               ?>
                 <!-- l'input nbreRepMultiple va stocker le nbre de reponses multiples possibles et est de visiblity:hidden -->
            <input type="text" name="nbreRepMultiple" id="nbreRepMultiple" class="d-none">
            <!-- l'input nbreRepSimple va stocker le nbre de reponses simples possibles et est de visiblity:hidden -->
            <input type="text" name="nbreRepSimple" id="nbreRepSimple" class="d-none">
            <button type="submit" class="btn btn-primary btn-seConnecter" id="btn-save">Enregistrer</button>
        </form>

        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
        <script src="../asset/JS/scriptJQuery8.js"></script>  
        <script src="../asset/JS/question.js"></script> 
    </body>
</html>