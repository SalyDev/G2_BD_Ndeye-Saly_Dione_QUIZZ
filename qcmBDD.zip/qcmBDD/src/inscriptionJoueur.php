<!doctype html>
<html lang="en">
    <head>
            <link rel="stylesheet" href="asset/CSS/design31.css">

    </head>
    <body>
        <div class="col col-lg-7 col-md-6 w-100 h-100 bg-white transblock mx-auto" id="idCompte">
            <img class="mx-auto img-logo" src="asset/images/logo-QuizzSA.png" id="idPp">
            <?php
                require "creationCompte.php";
            ?>
        </div> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
        <script src="asset/JS/scriptJQuery8.js"></script>  
    </body>
</html>