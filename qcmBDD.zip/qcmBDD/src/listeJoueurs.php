<!doctype html>
<html lang="en">
  <head></head>
  <body>
    <div class="col-12 col-lg-7 border border-primary mx-auto zone-listQst"></div>
    <form class="col-lg-8  mx-auto">
    <div class="form-group">
        <button type="submit" class="btn btn-primary btn-seConnecter float-left">Precedent</button>
        <button type="submit" class="btn btn-primary btn-seConnecter float-right">Suivant</button>
    </div>
    </form>
  </body>
</html>