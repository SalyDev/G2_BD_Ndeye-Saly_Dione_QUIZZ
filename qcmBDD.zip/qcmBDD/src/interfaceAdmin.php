<?php
    session_start();
    require "fonctions.php";
    deconnexion();
?>
<!doctype html>
<html lang="en">
    <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"> 

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="../asset/CSS/design35.css">
    </head>
    <body>
    <div class="container-fluid d-flex justify-content-center">
        <div class="col col-md-12 mt-2 w-25 bg-white transblock bloc-interfaceAdmin">
            <img class="mx-auto img-logo" src="../asset/images/logo-QuizzSA.png">
            <img src=<?php echo $_SESSION["avatar"]?> alt="Avatar" class="rounded-circle pp-admin">
                <div class="nomUser position-absolute">
                    Lissa Dione
                </div>
            <form method="POST">
                <button name="deconnexion" type="submit" id="" class="btn btn-primary btn-deconnexion mt-4">Deconnexion</button>
            </form>
            <div class="contain-admin mx-0">
                <div class="burger ml-4 mt-2">
                    <span></span>
                </div>
                <div class="menu ml-4">
                    <div class="row">
                            <div class="list-group">
                                <button id="list_1" type="button" class="list-group-item list-group-item-action">Liste des questions<span class="badge"><img src="../asset/images/icones/ic-liste.png"></span></button>
                                <button id="list_2" type="button" class="list-group-item list-group-item-action">Creer Admin<span class="badge"><img src="../asset/images/icones/ic-ajout.png"></span></button>
                                <button id="list_3" type="button" class="list-group-item list-group-item-action">Liste des joueurs<span class="badge"><img src="../asset/images/icones/ic-liste.png"></span></button>
                                <button id="list_4" type="button" class="list-group-item list-group-item-action">Creer questions<span class="badge"><img src="../asset/images/icones/ic-ajout.png"></span></button>
                            </div>
                    </div>
                </div>
                <div id="redirection" class="redirection pt-0 mt-2 mx-auto border-secondary position-relative">
                </div>
            </div>
        </div>
                <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
        <script src="../asset/JS/script1.js"></script> 
        <script src="../asset/JS/scriptJQuery7.js"></script>  
        <script>
            $('document').ready(function(){
                $('#redirection').load('http://localhost/qcmBDD/src/listeQuestions.php');
            })
        </script>
    </body>
</html>