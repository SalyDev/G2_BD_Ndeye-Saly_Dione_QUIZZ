<!doctype html>
<html lang="en">
  <head></head>
  <body>
    <div class="col h-100 d-flex flex-column flex-md-row flex-lg-row">
        <form method="POST">
            <div class="form-group col">
                <label for="idNQst">Nbre question/jeu</label>
                <input type="text" name="" id="idNQst" class="form-control col-4 col-lg-3 col-md-3 ml-2" placeholder="" aria-describedby="helpId">
                <small id="helpId" class="text-muted"></small>
                <button type="submit" class="btn btn-primary mt-1 ml-4 ml-lg-2 btn-ok">Ok</button>
            </div>
        </form>
        <div class="border border-primary  col-12 col-lg-7" id="zoneListQst">
            <table class="table">
               <tbody id="body-table" class="">
                </tbody>
            </table>
        </div>
        <div class="di"></div>
    </div>
    <script>
       $('document').ready(function(){
        let offset=0,
            limit=6;
        let tbody = $('tbody');
            $.post(
                'http://localhost/qcmBDD/traitement/getQst.php',
                {
                    offset:offset,
                    limit:limit
                },
                function(response){
                    console.log(response);
                    tbody.html('');
                    printData(response,tbody);
                    offset+=6;
                },
                'json'
                );
            //on gere le scrolling
            let zoneList = $('#zoneListQst');
            zoneList.scroll(function(){
                console.log("scrolling");
                const st = zoneList[0].scrollTop;
                const sh = zoneList[0].scrollHeight;
                const ch = zoneList[0].clientHeight;
                console.log(st,sh,ch);
                if(sh-st<=ch){
                    $.post(
                    'http://localhost/qcmBDD/traitement/getQst.php',
                    {
                        offset:offset,
                        limit:limit
                    },
                    function(response){
                        console.log(response);
                        printData(response,tbody);
                        offset+=6;
                    },
                    'json'
                    );
                }
            });
            //ajoute le type de la question dans la fonction afficheReponse
            function afficheReponse(reponse,type,exact){
                      check=[];
                for(j=0;j<exact.length;j++){
                    if(exact[j]==1){
                        check[j]="checked";
                    }
                }
                if(type=="multiple"){
                    for(j=0;j<reponse.length;j++){
                         tbody.append( "<tr><td><input name='choix"+i+" ' type='checkbox' "+check[j]+">"+reponse[j]+"</td></tr>"); 
                    }
                }
                else if(type=="simple"){
                    for(j=0;j<reponse.length;j++){
                         tbody.append( "<tr><td><input name='choix"+i+"' type='radio' "+check[j]+">"+reponse[j]+"</td></tr>"); 
                    }
                }
                else{
                     for(j=0;j<reponse.length;j++){
                         tbody.append( "<tr><td><input readonly name='rep' type='text' value=' "+ reponse[j]+"'></td></tr>"); 
                    }
                }
            }
            function printData(response,tbody){
               for(i=0;i<response["question"].length;i++){
                       tbody.append( "<tr><td class='libelleQst'>"+response['question'][i]+"<img class='float-right ml-2 editQst' src='../asset/images/icones/pencil.svg' id="+response['numQST'][i]+"><img class='float-right deleteQst' src='../asset/images/icones/ic-supprimer.png'  id="+response['numQST'][i]+"></td></tr>");
                   afficheReponse(response['reponse'][i],response['type'][i],response["exact"][i]); 
                       $(document).on('click', ".deleteQst", function(){
                           $.post(
                                 'http://localhost/qcmBDD/traitement/editQst.php',
                                {
                                    idQst:$(this).attr('id')
                                },
                                function(answer){
                                    console.log(answer);
                                },
                                'text'
                            );    

                            //on reload la section de liste de questions
                            $('#redirection').load('http://localhost/qcmBDD/src/listeQuestions.php');
                        })

                       //modification de question
                        $(document).on('click', ".editQst", function(){
                                // alert("hi");
                                $.post(
                                    'http://localhost/qcmBDD/traitement/editQst.php',
                                {
                                    idEdit:$(this).attr('id')
                                },
                                function(answer){
                                    console.log(answer);
                                },
                                'text'

                            );
                        })
                    }
                }
            })
        </script>
    </body>
</html>