<?php
  session_start();
  if(isset($_POST["loginSent"])){
    $bdd = connexionBD();
    $login = $_POST["loginSent"];
    $password = md5($_POST["passwordSent"]);
    $data = $bdd->query("SELECT * FROM users WHERE login='$login' AND password='$password'");
    if($data->rowCount() > 0){
      $data=$data->fetch();
      $_SESSION["log"]=1;
      $_SESSION["login"]=$login;
      $_SESSION["nom"]=$data["nom"];
      $_SESSION["prenom"]=$data["prenom"];
      $_SESSION["avatar"]=$data["avatar"];
      $_SESSION["profil"]=$data["profil"];
      if($data["profil"]=="admin"){
        exit("Vous êtes connecté en tant qu'administrateur");
      }
      if($data["profil"]=="joueur"){
        exit("Vous êtes connecté en tant que joueur");
      }
    }
    else{
       exit('<p class="text-white bg-danger w-100 w-100 position-absolute">Login ou mot de pass incorrect</p>');
      }
    }
?>
<!doctype html>
<html lang="en">
  <head></head>
  <body>
    <p class="text-center position-absolute erreur text-success" id="erreur"></p>
    <div class="col col-lg-6 col-md-6 h-75 mt-5 bg-white transblock">
      <img class="mx-auto img-logo" src="asset/images/logo-QuizzSA.png">
        <form class="mt-3" method="POST" action="connexion.php">
          <div class="input-group ml-2">
            <input type="text"  name="login" id="log" class="form-control col-10 bg-light" placeholder="Login" aria-describedby="helpId">
            <div class="input-group-append">
              <span class="input-group-text"><img src="asset/images/icones/ic-login.png"></span>
            </div>
            <small id="helpId" class="text-muted"></small>
            </div>
            <div class="input-group mb-5 mt-4 ml-2">
              <input type="password"  name="password" id="pass" class="form-control col-10 bg-light" placeholder="Password" aria-describedby="helpId">
              <div class="input-group-append">
                <span class="input-group-text"><img src="asset/images/icones/ic-password.png"></span>
              </div>
              <small id="helpId" class="text-muted"></small>
          </div>
          <button name="seConnecter" id="submit" class="btn btn-primary btn-seConnecter d-block mx-auto" type="submit" value="">Se connecter</button>
          <button name="creerCompte" type="button" class="btn btn-primary btn-creerCompte col-6 d-block mx-auto mt-3" id="createCompte">Creer un compte</button>
        </form>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script src="asset/JS/scriptJQuery6.js"></script>
  </body>
</html>